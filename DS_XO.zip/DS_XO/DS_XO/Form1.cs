﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DS_XO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Control c in panel2.Controls)
            {
                if(c is Button)
                {
                    c.Click +=new System.EventHandler(btn_click);

                }
            }
        }
        int XorO = 0, fstop = 0;
        public void btn_click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text.Equals("") && fstop == 0)
            {
                if (XorO % 2 == 0)
                {
                    btn.Text = "X";
                    btn.ForeColor = Color.DarkRed;
                    label1.Text = "O Player Turn";
                    getthewinner();
                }
                else
                {
                    btn.Text = "O";
                    btn.ForeColor = Color.Green;
                    label1.Text = "X Player Turn";
                    getthewinner();
                }
                XorO++;
            }
        }
        bool win = false;
        public void getthewinner()
        {
            if (!button1.Text.Equals("") && button1.Text.Equals(button2.Text) && button1.Text.Equals(button3.Text))
            {
                wineffect(button1, button2, button3);
                win = true;
                fstop = 1;
            }
            if (!button4.Text.Equals("") && button4.Text.Equals(button5.Text) && button4.Text.Equals(button6.Text))
            {
                wineffect(button4, button5, button6);
                win = true;
                fstop = 1;
            }
            if (!button7.Text.Equals("") && button7.Text.Equals(button8.Text) && button7.Text.Equals(button9.Text))
            {
                wineffect(button7, button8, button9);
                win = true;
                fstop = 1;
            }
            if (!button1.Text.Equals("") && button1.Text.Equals(button4.Text) && button1.Text.Equals(button7.Text))
            {
                wineffect(button1, button4, button7);
                win = true;
                fstop = 1;
            }
            if (!button2.Text.Equals("") && button2.Text.Equals(button5.Text) && button2.Text.Equals(button8.Text))
            {
                wineffect(button2, button5, button8);
                win = true;
                fstop = 1;
            }
            if (!button3.Text.Equals("") && button3.Text.Equals(button6.Text) && button3.Text.Equals(button9.Text))
            {
                wineffect(button3, button6, button9);
                win = true;
                fstop = 1;
            }
            if (!button1.Text.Equals("") && button1.Text.Equals(button5.Text) && button1.Text.Equals(button9.Text))
            {
                wineffect(button1, button5, button9);
                win = true;
                fstop = 1;
            }
            if (!button3.Text.Equals("") && button3.Text.Equals(button5.Text) && button3.Text.Equals(button7.Text))
            {
                wineffect(button3, button5, button7);
                win = true;
                fstop = 1;
            }
            if (btns_length() == 9 && win == false)
            {
                label1.Text = "DRAW";
            }
        }

        public int btns_length()
        {
            int button_text_length = 0;
            foreach (Control c in panel2.Controls)
            {
                if (c is Button)
                {
                    button_text_length += c.Text.Length;

                }
            }
            return button_text_length;
        }

        public void wineffect(Button b1, Button b2, Button b3)
        {
            b1.BackColor = Color.Green;
            b2.BackColor = Color.Green;
            b3.BackColor = Color.Green;

            b1.ForeColor = Color.White;
            b2.ForeColor = Color.White;
            b3.ForeColor = Color.White;

            label1.Text = b1.Text + " Win";

        }

        private void button10_Click(object sender, EventArgs e)
        {
            XorO = 0;
            fstop = 0;
            win = false;
            label1.Text = "Play Now";
            foreach (Control c in panel2.Controls)
            {
                if (c is Button)
                {
                    c.Text = "" ;
                    c.BackColor = Color.White;

                }
            }
        }

    }
}
